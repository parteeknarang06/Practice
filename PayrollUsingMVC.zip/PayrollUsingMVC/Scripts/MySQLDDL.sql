ALTER TABLE `newemployeedb2`.`employee` 
CHANGE COLUMN `empId` `empId` INT(11) NOT NULL AUTO_INCREMENT ,
ADD PRIMARY KEY (`empId`);
;