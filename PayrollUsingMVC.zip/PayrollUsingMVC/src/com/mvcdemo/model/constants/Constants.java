/*package com.mvcdemo.model.constants;

public class Constants {
	public static final String URL = "jdbc:mysql://localhost:3306/newemployeedb2";
	public static final String USER = "root";
	public static final String PASS = "root";
	public static final String NAME = "com.mysql.jdbc.Driver";
	public static final String EMPLOYEE_TABLE_NAME = "employee";
}*/
