package com.mvcdemo.model.ignore;

public class Ignore {

	public static void main(String[] args) {
		System.out.println("Create employee entries: ");
		System.out.println("------------------------");
	}

}
