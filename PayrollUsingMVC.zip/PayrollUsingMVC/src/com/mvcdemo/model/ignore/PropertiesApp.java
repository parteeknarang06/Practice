package com.mvcdemo.model.ignore;

import com.mvcdemo.util.PropertiesCache;

public class PropertiesApp {

	public static void main(String[] args) {
		//Get individual properties
		PropertiesCache pc = PropertiesCache.getInstance();
		System.out.println(pc.getProperty("URL"));
		System.out.println(pc.getProperty("NAME"));
	   
		//All property names
		//System.out.println(pc.getAllPropertyNames());
	}

}
