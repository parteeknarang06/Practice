package com.mvcdemo.model.dao;

import java.sql.Connection;
import java.sql.ResultSet;

import com.mvcdemo.model.pojo.Employee;

public interface Dao {
	//create
	void storeDailyTypeDataInDb(Employee emp, Connection con);
	//create
	void storeSalariedTypeDataInDb(Employee emp, Connection con);
	//create
	void storeCommissionTypeDataInDb(Employee emp, Connection con);
	Connection getConnection();
	//read
	public ResultSet searchForEmp(String searchEmail, Connection con);
	public String checkIfDataInserted();
}
