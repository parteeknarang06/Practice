package com.destm.json;

import com.destm.json.model.UserBean;

import java.util.List;

public interface JsonOperations {
  
  List<UserBean> getAllData();
}
