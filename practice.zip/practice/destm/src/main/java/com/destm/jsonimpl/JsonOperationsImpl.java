package com.destm.jsonimpl;

import com.destm.json.JsonOperations;
import com.destm.json.model.UserBean;

import java.util.List;

import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

public class JsonOperationsImpl implements JsonOperations {

  @Override
  public List<UserBean> getAllData() {
    RestTemplate template = new RestTemplate();
    String url = "http://jsonplaceholder.typicode.com/posts";
    ResponseEntity<List<UserBean>> response = template.exchange(url, 
        HttpMethod.GET, 
        null,
        new ParameterizedTypeReference<List<UserBean>>() {
        });
    return response.getBody();
  }

}
