package com.destm.controllers;

import com.destm.json.JsonOperations;
import com.destm.json.model.UserBean;
import com.destm.jsonimpl.JsonOperationsImpl;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/jsonFeed")
public class JsonFeedController {

  @GetMapping("/getData")
  public List<UserBean> getJsonData() {
    JsonOperations jsonOperations = new JsonOperationsImpl();
    return jsonOperations.getAllData();
  }
  
  @GetMapping("/getModifiedData")
  public List<UserBean> getModifiedData() {
    JsonOperations jsonOperations = new JsonOperationsImpl();
    List<UserBean> list = jsonOperations.getAllData();
    UserBean fourth = list.stream().filter(element -> element.getId() == 4).findFirst().get();
    fourth.setTitle("1800Flowers");
    fourth.setBody("1800Flowers");
    return list;
  }
  
  @GetMapping("/getUniqueUserIds")
  public Set<Integer> getUniqueUserIds() {
    JsonOperations jsonOperations = new JsonOperationsImpl();
    List<UserBean> list = jsonOperations.getAllData();
    return list.stream().map(element -> element.getUserId()).collect(Collectors.toSet());
  }
  
}
