package com.destm.test.mockitoJunitRunner;

import static org.mockito.Mockito.mock;

import com.destm.json.model.UserBean;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.springframework.test.util.ReflectionTestUtils;

public class MockedResult {

  public static List<UserBean> getMockedUsers() {
    return getUsersList();
  }
  
  public static List<UserBean> getMockedModifiedMockedUsers() {
    List<UserBean> users = getUsersList();
    UserBean user = users.get(3);
    ReflectionTestUtils.setField(user, "title", "1800Flowers", String.class);
    ReflectionTestUtils.setField(user, "body", "1800Flowers", String.class);
    ReflectionTestUtils.setField(user, "id", 4);
    return users;
  }
  
  public static Set<Integer> getMockedUniqueUserIds() {
    return IntStream.rangeClosed(1, 10).boxed().collect(Collectors.toSet());
  }

  private static List<UserBean> getUsersList() {
    return new ArrayList<UserBean>() {
      private static final long serialVersionUID = 1L;
      {
        IntStream.iterate(1, i -> i++).limit(100).forEach(element -> {
          add(mock(UserBean.class));
        });
      }
    };
  }
  
}
