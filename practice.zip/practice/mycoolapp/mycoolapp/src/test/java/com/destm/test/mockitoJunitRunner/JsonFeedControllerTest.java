package com.destm.test.mockitoJunitRunner;

import com.destm.controllers.JsonFeedController;
import com.destm.json.JsonOperations;
import com.destm.json.model.UserBean;

import java.util.List;
import java.util.Set;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.test.util.ReflectionTestUtils;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class JsonFeedControllerTest {
  
  @InjectMocks
  private JsonFeedController jsonFeedController;

  @Mock
  private JsonOperations jsonOperations;

  @Test
  public void checkAllData() {
    when(jsonOperations.getUsers()).thenReturn(MockedResult.getMockedUsers());
    List<UserBean> list = jsonFeedController.getUsers();
    int expectedUsers = 100;
    assertEquals(expectedUsers, list.size());
  }

  @Test
  public void getModifiedData() {
    when(jsonOperations.getModifiedUsers()).thenReturn(MockedResult.getMockedModifiedMockedUsers());
    List<UserBean> list = jsonFeedController.getModifiedUsers();
    UserBean user = list.get(3);
    assertEquals("1800Flowers", ReflectionTestUtils.getField(user, "title"));
    assertEquals("1800Flowers", ReflectionTestUtils.getField(user, "body"));
    assertEquals(4, ReflectionTestUtils.getField(user, "id"));
  }
  
  @Test
  public void getUniqueUserIds() {
    when(jsonOperations.getUniqueUserIds()).thenReturn(MockedResult.getMockedUniqueUserIds());
    Set<Integer> list = jsonFeedController.getUniqueUserIds();
    int expectedUsers = 10;
    assertEquals(expectedUsers, list.size());
  }
  
  
}
