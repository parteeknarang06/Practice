package com.destm.json;

import com.destm.json.model.UserBean;

import java.util.List;
import java.util.Set;

public interface JsonOperations {

  List<UserBean> getUsers();

  List<UserBean> getModifiedUsers();

  public Set<Integer> getUniqueUserIds();
}
