package com.destm.controllers;

import com.destm.json.JsonOperations;
import com.destm.json.model.UserBean;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/jsonFeed")
public class JsonFeedController {

  private final JsonOperations jsonOperations;

  @Autowired
  public JsonFeedController(JsonOperations jsonOperations) {
    this.jsonOperations = jsonOperations;
  }

  @GetMapping("/getHelloWorld")
  public String getHelloWorld() {
    return "Hello World";
  }
  
  @GetMapping("/getUsers")
  public List<UserBean> getUsers() {
    return jsonOperations.getUsers();
  }

  @GetMapping("/getModifiedUsers")
  public List<UserBean> getModifiedUsers() {
    return jsonOperations.getModifiedUsers();
  }

  @GetMapping("/getUniqueUserIds")
  public Set<Integer> getUniqueUserIds() {
    return jsonOperations.getUniqueUserIds();
  }

  @GetMapping("/getDummyUser")
  public UserBean getDummyUser() {
    return new UserBean(101, 1, "1800Flowers", "1800Flowers");
  }
}
