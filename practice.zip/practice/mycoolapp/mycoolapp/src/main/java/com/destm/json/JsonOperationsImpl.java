package com.destm.json;

import com.destm.json.model.UserBean;
import com.destm.json.rest.JsonRestClass;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class JsonOperationsImpl implements JsonOperations {

  private final JsonRestClass jsonRestClass;

  @Autowired
  public JsonOperationsImpl(JsonRestClass jsonRestClass) {
    this.jsonRestClass = jsonRestClass;
  }

  @Override
  public List<UserBean> getUsers() {
    return jsonRestClass.getJsonFeedUsers();
  }

  @Override
  public List<UserBean> getModifiedUsers() {
    List<UserBean> list = jsonRestClass.getJsonFeedUsers();
    UserBean fourth = list.stream().filter(element -> element.getId() == 4).findFirst().get();
    fourth.setTitle("1800Flowers");
    fourth.setBody("1800Flowers");
    return list;
  }

  @Override
  public Set<Integer> getUniqueUserIds() {
    List<UserBean> list = jsonRestClass.getJsonFeedUsers();
    return list.stream().map(element -> element.getUserId()).collect(Collectors.toSet());
  }

}
