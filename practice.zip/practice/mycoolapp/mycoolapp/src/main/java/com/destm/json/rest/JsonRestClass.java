package com.destm.json.rest;

import com.destm.json.model.UserBean;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

public class JsonRestClass {

  @Autowired
  private RestTemplate template;

  public List<UserBean> getJsonFeedUsers() {
    String url = "http://jsonplaceholder.typicode.com/posts";
    ResponseEntity<List<UserBean>> response = template.exchange(url, HttpMethod.GET, null,
        new ParameterizedTypeReference<List<UserBean>>() {
        });
    return response.getBody();
  }
}
