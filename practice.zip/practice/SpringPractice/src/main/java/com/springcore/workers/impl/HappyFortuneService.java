package com.springcore.workers.impl;

import com.springcore.workers.FortuneService;

public class HappyFortuneService implements FortuneService {

  public HappyFortuneService() {
    System.out.println("HappyFortuneService cons");
  }
  
  @Override
  public String getFortune() {
    return "Today is your lucky day";
  }

}
