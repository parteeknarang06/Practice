package com.springcore.workers;

public interface FortuneService {
  
  public String getFortune();
  
}
