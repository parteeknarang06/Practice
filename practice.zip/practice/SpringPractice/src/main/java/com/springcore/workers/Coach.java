package com.springcore.workers;

public interface Coach {
  
  String getDailyWorkout();
  
  String getDailyFortune();
}
