package com.springboot.resolver;

import com.springboot.controller.service.EmployeeService;
import com.springboot.dao.EmployeeDao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.web.client.RestTemplate;

@Configuration
public class CandidateResolver {

  @Value("${dao.vendor}")
  private String dao;
 
  @Value("${service.name}")
  private String serviceName;
  
  @Autowired
  private ApplicationContext context;
  
  @Bean
  //@Qualifier("runDao")
  @Primary
  public EmployeeDao getEmployeeDao() {
    return context.getBean(dao, EmployeeDao.class);
  }
  
  @Bean
  @Primary
  public EmployeeService getEmployeeService() {
    return context.getBean(serviceName, EmployeeService.class);
  }
  
  @Bean
  public RestTemplate getRestTemplate(RestTemplateBuilder builder) {
    return builder.build();
  }
  
}
