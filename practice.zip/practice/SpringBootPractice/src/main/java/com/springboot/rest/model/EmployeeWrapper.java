package com.springboot.rest.model;

public class EmployeeWrapper {

  private Employee data;

  public Employee getData() {
    return data;
  }

  public void setData(Employee data) {
    this.data = data;
  }

}
