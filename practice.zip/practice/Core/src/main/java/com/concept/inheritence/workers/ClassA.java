package com.concept.inheritence.workers;

public class ClassA {
  
  public void m1() {
    System.out.println("ClassA m1");
  }
  
}
