package com.concept.inheritence;

import com.concept.inheritence.workers.Alarm;
import com.concept.inheritence.workers.Vehicle;

public class StaticMethodOverrding {

  public static void main(String[] args) {
    

  }
  
  private static void m1(Alarm al) {
    
  }

  private static void m1(Vehicle al) {
    
  }
}