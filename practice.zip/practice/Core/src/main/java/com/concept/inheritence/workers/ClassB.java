package com.concept.inheritence.workers;

public class ClassB extends ClassA {

  public void m1() {
    System.out.println("ClassB m1");
  }
  
  public void m2() {
    System.out.println("ClassB m2");
  }
}
