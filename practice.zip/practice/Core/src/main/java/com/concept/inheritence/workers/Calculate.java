package com.concept.inheritence.workers;

public interface Calculate {

  void add();

  void substract();

  void divide();

  void multiply();
  
  void additiveMultiply();
  
  void additiveDivide();
  
  void equals();
}
