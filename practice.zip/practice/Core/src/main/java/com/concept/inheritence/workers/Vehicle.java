package com.concept.inheritence.workers;

public abstract class Vehicle implements Alarm {

  @Override
  public void trunAlarmOff() {
    // TODO Auto-generated method stub
    
  }
  @Override
  public void automaticAlarmOn() {
    trunAlarmOn();
  }
  
  @Override
  public void trunAlarmOn() {
    
  }
  protected static void test() {
    
  }
  
  protected void test1() {
    
  }
  
  //protected abstract static void test1();
}
