package com.concept.inheritence.workers;

public interface Alarm {

  void trunAlarmOn();

  void trunAlarmOff();

  void automaticAlarmOn();
}
