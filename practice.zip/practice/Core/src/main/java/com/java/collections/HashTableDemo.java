package com.java.collections;

import java.util.Hashtable;
import java.util.HashMap;
import java.util.HashSet;

public class HashTableDemo {

  public static void main(String[] args) {
    HashSet set = new HashSet<>();
    

  }

}
