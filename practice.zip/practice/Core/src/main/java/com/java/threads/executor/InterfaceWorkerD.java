package com.java.threads.executor;

public interface InterfaceWorkerD {
  void start() throws InterruptedException;

  void getResult() throws InterruptedException;
}
