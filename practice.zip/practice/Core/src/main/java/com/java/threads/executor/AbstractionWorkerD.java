package com.java.threads.executor;

public abstract class AbstractionWorkerD implements InterfaceWorkerD {

  

}
