package com.selenium.creation;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class GoogleDrive {

  public static void main(String[] args) throws InterruptedException {
    System.setProperty("webdriver.chrome.driver", "/home/dataguise/Downloads/chromedriver_linux64/chromedriver");
    WebDriver driver = new ChromeDriver();
    // comment the above 2 lines and uncomment below 2 lines to use Chrome
    // System.setProperty("webdriver.chrome.driver","G:\\chromedriver.exe");
    // WebDriver driver = new ChromeDriver();

    String baseUrl = "https://accounts.google.com/SignUp?hl=en";
    // launch Fire fox and direct it to the Base URL
    driver.get(baseUrl);
    driver.manage().timeouts().implicitlyWait(10, TimeUnit.MINUTES);

    sendKeysOnElementByName(driver, "firstName", "Prateek");
    sendKeysOnElementByName(driver, "lastName", "Narang");
    sendKeysOnElementByName(driver, "Username", "cs.prateeknarang.6");
    sendKeysOnElementByName(driver, "Passwd", "test123test123");
    sendKeysOnElementByName(driver, "ConfirmPasswd", "test123test123");
    clickElementById(driver, "accountDetailsNext");
    sendKeysOnElementById(driver, "phoneNumberId", "9855562499");
    /*
     * element = driver.findElement(By.name()); element.sendKeys();
     * 
     * element = driver.findElement(By.name("lastName"));
     * element.sendKeys("Narang");
     * 
     * element = driver.findElement(By.name("Username")); element.sendKeys("");
     * 
     * element = driver.findElement(By.id("initialView")); element =
     * element.findElement(By.xpath("//span[@aria-label='For myself']/div[2]/div"));
     * System.out.println(element.getAttribute("class"));
     * //element.sendKeys(Keys.ENTER); element.click(); // get the actual value of
     * the title
     * 
     * /* compare the actual title of the page with the expected one and print the
     * result as "Passed" or "Failed"
     */

    // close Fire fox
    // driver.close();

  }

  private static void sendKeysOnElementByName(WebDriver driver, String nameTagValue, String sendKeys) {
    driver.findElement(By.name(nameTagValue)).sendKeys(sendKeys);
  }

  private static void sendKeysOnElementById(WebDriver driver, String id, String sendKeys) {
    driver.findElement(By.id(id)).sendKeys(sendKeys);
  }
  
  private static void clickElementById(WebDriver driver, String id) {
    driver.findElement(By.id(id)).click();
  }

}
