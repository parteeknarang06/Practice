package Core;

public class ClassA {
  public static String s1 = "abc";
  static {
    System.out.println(s1.charAt(0));
  }
  
  public static String get() {
    return s1;
    
  }
}
