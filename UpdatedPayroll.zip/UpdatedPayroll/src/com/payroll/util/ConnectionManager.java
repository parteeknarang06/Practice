package com.payroll.util;

import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Connection;

public class ConnectionManager {
	private static PropertiesCache propertiesFile = PropertiesCache.getInstance();
	public static Connection getConnection() {
		Connection con = null;
		try {
			//Register JDBC driver
			Class.forName(propertiesFile.getProperty("NAME"));
			//Open a connection
			con = DriverManager.getConnection(propertiesFile.getProperty("URL"), propertiesFile.getProperty("USER"), propertiesFile.getProperty("PASSWORD"));
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			System.out.println("Driver not found.");
		} catch (SQLException e) {
			System.out.println("Failed to create database connection.");;
		}
		
		return con;
	}
}
