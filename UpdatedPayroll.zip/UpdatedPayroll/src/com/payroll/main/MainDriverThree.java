package com.payroll.main;

import java.util.Calendar;

public class MainDriverThree {
	public static void main(String args []) {
		Calendar calendar = Calendar.getInstance();
		int year = 2019;
		int month = Calendar.JUNE;
		int date = 16;
		calendar.set(year, month);
		
		int maximumDays = calendar.getActualMaximum(Calendar.DAY_OF_MONTH);
		System.out.print(maximumDays);
	}
	
	public int getNumberOfDays(int month){
		Calendar calendar = Calendar.getInstance();
		calendar.set(Calendar.MONTH, month);
		int year = 2019;
		int day = 16;
		calendar.set(year, month, day);
		
		int maximumDays = calendar.getActualMaximum(Calendar.DAY_OF_MONTH);
		return maximumDays;
	}
	
}
