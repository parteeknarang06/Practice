package com.payroll.main;

import java.util.List;
import java.util.ListIterator;

import com.payroll.DAO.EmployeeDAOImpl;
import com.payroll.employees.CommissionEmployee;
import com.payroll.employees.HourlyEmployee;
import com.payroll.employees.SalariedCommissionEmployee;
import com.payroll.employees.SalariedEmployee;

public class MainDriverTwo {

	public static void main(String[] args) {
		
		EmployeeDAOImpl operations = new EmployeeDAOImpl();
		
		//MAKE ENTRIES: SalariedEmployee
		SalariedEmployee emp1 = new SalariedEmployee("Neelesh Narang", "p@gmail.com", 784, 50000, 25, 4);
		//SAVE ENTRIES: SalariedEmployee
		System.out.println();
		System.out.println("salaried emp1 saved: " + operations.saveSalariedEmployee(emp1));
		
		
		//MAKE ENTRIES: HourlyEmployee
		//HourlyEmployee emp2 = new HourlyEmployee("Rounak Banik", "r@yahoo.com", 1004, 732, 110);
		//SAVE ENTRIES: HourlyEmployee
		//System.out.println();
		//System.out.println("hourly emp2 saved " + operations.saveHourlyEmployee(emp2));
		
		
		/*
		//MAKE ENTRIES: CommissionEmployee
		//CommissionEmployee emp3 = new CommissionEmployee("Ravi Mittal", "ravi@gmail.com", 1005, 720, 98);
		CommissionEmployee emp5 = new CommissionEmployee("Sunil Singh", "sunil@gmail.com", 1007, 0.5, 150000);
		//SAVE ENTRIES: CommissionEmployee
		System.out.println();
		//System.out.println("commission emp3 saved: " + operations.saveCommissionEmployee(emp3));
		System.out.println("commission emp5 saved: " + operations.saveCommissionEmployee(emp5));
		*/
		/*
		//MAKE ENTRIES: SalariedCommissionEmployee
		SalariedCommissionEmployee emp4 = new SalariedCommissionEmployee("Sam Chaudhary", "sam@outlook.com", 1013, 0.6, 15000, 20000);
		//SAVE ENTRIES: SalariedCommissionEmployee
		System.out.println();
		System.out.println("salaried commission emp4 saved: " + operations.saveSalariedCommissionEmployee(emp4));
		*/
		/*
		List <SalariedEmployee> salariedEmpList = operations.getSalariedEmpById(786);
		
		ListIterator<SalariedEmployee> iterator = salariedEmpList.listIterator();
		
		// Printing the iterated value 
		System.out.println("\nUsing ListIterator:\n"); 
		while (iterator.hasNext()) { 
			System.out.println("Name is: " + iterator.next().getEarnings());
		*/
		}
		

}
