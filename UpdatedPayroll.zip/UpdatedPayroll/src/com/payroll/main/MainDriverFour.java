package com.payroll.main;

import java.util.*;

public class MainDriverFour {
  public static void main(String[] args) {
	  System.out.println(getNumberOfDays(2));
  }
  
  public static int getNumberOfDays(int monthNumber) {
	  int month;
	  if(monthNumber >= 1 && monthNumber <= 12) {
		  month = monthNumber;  
	  }
	  else {
		  throw new IllegalArgumentException("Enter valid entry between 1 - 12 only.");
	  }
	 
	  // GregorianCalendar months range from 0 to 11
	  month = month - 1;
	 
	  int year = 2019; 
	 
	  Calendar cal = new GregorianCalendar();
	  cal.set(Calendar.YEAR,year);
	  cal.set(Calendar.MONTH,month);
	 
	  int noOfDays = cal.getActualMaximum(Calendar.DAY_OF_MONTH);
	 
	  return noOfDays; 
		  
  }
  
}