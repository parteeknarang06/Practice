package com.payroll.main;

import java.util.List;
import java.util.ListIterator;

import com.payroll.DAO.EmployeeDAO;
import com.payroll.DAO.EmployeeDAOImpl;
import com.payroll.employees.CommissionEmployee;
import com.payroll.employees.HourlyEmployee;
import com.payroll.employees.SalariedCommissionEmployee;
import com.payroll.employees.SalariedEmployee;

public class MainDriver {

	public static void main(String[] args) {
		
		EmployeeDAO operations = new EmployeeDAOImpl();
		
		//test salaried employee
		SalariedEmployee emp1 = new SalariedEmployee("Shubham Pandey", "sh@gmail.com", 1012, 54000, 30);
		
		
		System.out.println(operations.saveSalariedEmployee(emp1));
		
		
		//MAKE ENTRIES: hourly employee
		HourlyEmployee emp2 = new HourlyEmployee("Prateek Narang", "pNarang@gmail.com", 1013, 310, 121);
		HourlyEmployee emp5 = new HourlyEmployee("Neelesh Misra", "N@gmail.com", 420, 120, 116);
		//SAVE ENTRIES: hourly employee
		System.out.println(operations.saveHourlyEmployee(emp2));
		System.out.println(operations.saveHourlyEmployee(emp5));
		
		//MAKE ENTRIES: commission employee
		CommissionEmployee emp4 = new CommissionEmployee("aa", "a@g.com", 765, 0.3, 98);
		System.out.println(operations.saveCommissionEmployee(emp4));
		
		
		//MAKE ENTRIES: salariedCommission employee
		SalariedCommissionEmployee emp3 = new SalariedCommissionEmployee("Shubham", "Shubham@g.com", 432, 0.3, 25000, 100);
		System.out.println();
		
		
		System.out.println(operations.saveSalariedCommissionEmployee(emp3));
				
		
		
		List <SalariedEmployee> empList = operations.getAllSalariedEmployee();
		System.out.println("Employees ArrayList: " + empList);
		System.out.println();
		
		List <HourlyEmployee> hourlyEmpList = operations.getAllHourlyEmployee();
		System.out.println("Hourly employees ArrayList: " + hourlyEmpList);
		
		
		ListIterator<HourlyEmployee> 
        iterator = hourlyEmpList.listIterator(); 

		// Printing the iterated value 
		System.out.println("\nUsing ListIterator:\n"); 
		while (iterator.hasNext()) { 
		    System.out.println("Value is : "
		                       + iterator.next().getEarnings()); 
		}
		
//		SalariedEmployee tempVar = empList.get(0);
//		
//		System.out.println();
//		System.out.println("Value of temp emp is: " + tempVar.getEarnings());
		
	}

}
