package com.payroll.DAO;

import java.util.List;

import com.payroll.employees.CommissionEmployee;
import com.payroll.employees.Employee;
import com.payroll.employees.HourlyEmployee;
import com.payroll.employees.SalariedCommissionEmployee;
import com.payroll.employees.SalariedEmployee;


public interface EmployeeDAO {
	//CREATE
	boolean saveSalariedEmployee(SalariedEmployee emp);
	boolean saveCommissionEmployee(CommissionEmployee emp);
	boolean saveHourlyEmployee(HourlyEmployee emp);
	boolean saveSalariedCommissionEmployee(SalariedCommissionEmployee emp);
	
	//READ
	List<List> getAllEmployee(); 
	List<SalariedEmployee> getAllSalariedEmployee();
	List<HourlyEmployee> getAllHourlyEmployee();
	List<CommissionEmployee> getAllCommissionEmployee();
	List<SalariedCommissionEmployee> getAllSalariedCommissionEmployee();
	
	List<SalariedEmployee> getSalariedEmpById(int empId);
	List<HourlyEmployee> getHourlyEmpById(int empId);
	List<CommissionEmployee> getCommissionEmpById(int empId);
	List<SalariedCommissionEmployee> getSalariedCommissionEmpById(int empId);
	
	//UPDATE
	
	
	//DELETE

	
}
