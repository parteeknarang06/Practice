package com.payroll.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import com.payroll.employees.CommissionEmployee;
import com.payroll.employees.Employee;
import com.payroll.employees.HourlyEmployee;
import com.payroll.employees.SalariedCommissionEmployee;
import com.payroll.employees.SalariedEmployee;
import com.payroll.util.ConnectionManager;

public class EmployeeDAOImpl implements EmployeeDAO {

    public static final String INSERT_EMPLOYEE = "insert into employee (emp_id, full_name, email) "
    		+ "values(?,?,?)";
    public static final String INSERT_SALARIED_EMP = "insert into salaried_employee (emp_id, weekly_salary) "
    		+ "values(?,?)";
    public static final String INSERT_COMMISSION_EMPLOYEE = "insert into commission_employee (emp_id, rate, sale, earnings) "
    		+ "values(?,?,?,?)";
    public static final String INSERT_HOURLY_EMPLOYEE = "insert into hourly_employee (emp_id, hourly_wage, hours_worked, earnings) "
    		+ "values(?,?,?,?)";
    public static final String INSERT_SALARIED_COMMISSION_EMPLOYEE = "insert into salaried_commission_employee (emp_id, rate, sale, salary, bonus, earnings) "
    		+ "values(?,?,?,?,?,?)";
    public static final String SELECT_ALL_SALARIED_EMPLOYEE = "select e.emp_id,full_name,email, weekly_salary, salary_month, working_days, salary_month, working_days from employee e "
    		+ "inner join salaried_employee se on e.emp_id=se.emp_id";
    public static final String SELECT_ALL_HOURLY_EMPLOYEE = "select e.emp_id,full_name,email, hourly_wage, hours_worked, earnings from employee e "
    		+ "inner join hourly_employee es on e.emp_id=es.emp_id";
    public static final String SELECT_ALL_COMMISSION_EMPLOYEE = "select e.emp_id, full_name, email, rate, sale, earnings from employee e " 
    		+ "inner join commission_employee es on e.emp_id=es.emp_id";
    public static final String SELECT_ALL_SALARIED_COMMISSION_EMPLOYEE = "select e.emp_id,full_name,email, rate, sale, salary, bonus, earnings from employee e " 
    		+ " inner join salaried_commission_employee es on e.emp_id=es.emp_id ";
    public static final String SELECT_SALARIED_EMPLOYEE_BY_ID = "select e.emp_id,full_name,email, weekly_salary from employee e inner join salaried_employee es "
    		+ " on e.emp_id=es.emp_id where e.emp_id=? ";
    public static final String SELECT_HOURLY_EMPLOYEE_BY_ID = "select e.emp_id,full_name,email, hourly_wage, hours_worked, earnings from employee e "
    		+ " inner join hourly_employee es on e.emp_id=es.emp_id where e.emp_id=? ";
    public static final String SELECT_COMMISSION_EMPLOYEE_BY_ID = "select e.emp_id, full_name, email, rate, sale, earnings from employee e "
    		+ "	inner join commission_employee es on e.emp_id=es.emp_id where e.emp_id=?";
    public static final String SELECT_SALARIED_COMMISSION_EMPLOYEE_BY_ID = "select e.emp_id,full_name,email, rate, sale, salary, bonus, earnings from employee e "
    		+ "inner join salaried_commission_employee es on e.emp_id=es.emp_id where e.emp_id=?";
    
	private void saveEmployee(Connection con,Employee emp) throws SQLException {
    	PreparedStatement ps = con.prepareStatement(INSERT_EMPLOYEE);
		ps.setInt(1, emp.getEmpId());
		ps.setString(2, emp.getFullName());
		ps.setString(3, emp.getEmail());
		ps.executeUpdate();
		closeResources(null, ps, null);
	}
    
    @Override
	public boolean saveSalariedEmployee(SalariedEmployee emp) {
    	Connection con = ConnectionManager.getConnection();
		PreparedStatement ps = null;
		boolean isExecuted = false;
		try {
			con.setAutoCommit(false);
			saveEmployee(con,emp);
			ps = con.prepareStatement(INSERT_SALARIED_EMP);
			ps.setInt(1, emp.getEmpId());
			ps.setDouble(2, emp.getEarnings());
			isExecuted = ps.executeUpdate()>0 ? true : false;
			con.commit();
		}
		catch (SQLException e) {
			e.printStackTrace();
		}finally {
			closeResources(null, ps, con);
		}
		return isExecuted;
	}

	@Override
	public boolean saveCommissionEmployee(CommissionEmployee emp) {
		Connection con = ConnectionManager.getConnection();
		PreparedStatement ps = null;
		boolean isExecuted = false;
		try {
			con.setAutoCommit(false);
			saveEmployee(con,emp);
			ps = con.prepareStatement(INSERT_COMMISSION_EMPLOYEE);
			ps.setInt(1, emp.getEmpId());
			ps.setDouble(2, emp.getRate());
			ps.setDouble(3, emp.getSale());
			ps.setDouble(4, emp.getEarnings());
			isExecuted = ps.executeUpdate()>0 ? true : false;
			con.commit();
		}
		catch (SQLException e) {
			e.printStackTrace();
		}finally {
			closeResources(null, ps, con);
		}
		return isExecuted;
	}

	@Override
	public boolean saveHourlyEmployee(HourlyEmployee emp) {
		Connection con = ConnectionManager.getConnection();
		PreparedStatement ps = null;
		boolean isExecuted = false;
		try {
			con.setAutoCommit(false);
			saveEmployee(con,emp);
			ps = con.prepareStatement(INSERT_HOURLY_EMPLOYEE);
			ps.setInt(1, emp.getEmpId());
			ps.setDouble(2, emp.getHourlyWage());
			ps.setDouble(3, emp.getHoursWorked());
			ps.setDouble(4, emp.getEarnings());
			isExecuted = ps.executeUpdate()>0 ? true : false;
			con.commit();	
		}
		catch (SQLException e) {
			e.printStackTrace();
		}finally {
			closeResources(null, ps, con);
		}
		return isExecuted;
	}

	@Override
	public boolean saveSalariedCommissionEmployee(SalariedCommissionEmployee emp) {
		Connection con = ConnectionManager.getConnection();
		PreparedStatement ps = null;
		boolean isExecuted = false;
		try {
			con.setAutoCommit(false);
			saveEmployee(con,emp);
			ps = con.prepareStatement(INSERT_SALARIED_COMMISSION_EMPLOYEE);
			ps.setInt(1, emp.getEmpId());
			ps.setDouble(2, emp.getRate());
			ps.setDouble(3, emp.getSale());
			ps.setDouble(4, emp.getSalary());
			ps.setDouble(5, emp.getBonus());
			ps.setDouble(6, emp.getEarnings());
			isExecuted = ps.executeUpdate()>0 ? true : false;
			con.commit();
		}
		catch (SQLException e) {
			e.printStackTrace();
		}finally {
			closeResources(null, ps, con);
		}
		return isExecuted;
	}

	private void closeResources(ResultSet resultSet, Statement stmt, Connection con) {
		try {
			if(resultSet!=null)
				resultSet.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		try {
			if(stmt!=null)
				stmt.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		try {
			if(con!=null)
				con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	@Override
	public List<SalariedEmployee> getAllSalariedEmployee() {
		Connection con = ConnectionManager.getConnection();
		Statement stmt = null;
		ResultSet rs = null;
		List<SalariedEmployee> salariedEmployeeList = null;
		try {
			stmt = con.createStatement();
			rs = stmt.executeQuery(SELECT_ALL_SALARIED_EMPLOYEE);
			salariedEmployeeList = new ArrayList<SalariedEmployee>();
			while(rs.next()) {
				SalariedEmployee salariedEmp = new SalariedEmployee(rs.getString(2), rs.getString(3), rs.getInt(1), rs.getDouble(4), rs.getInt(6), rs.getInt(5));
				//SalariedEmployee salariedEmp = new SalariedEmployee(fullName, email, empId, monthlySalary, workingDays, salaryMonth)
				salariedEmployeeList.add(salariedEmp);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			closeResources(rs, stmt, con);
		}
		
		return salariedEmployeeList;
	}

	@Override
	public List<HourlyEmployee> getAllHourlyEmployee() {
		Connection con = ConnectionManager.getConnection();
		Statement stmt = null;
		ResultSet rs = null;
		List<HourlyEmployee> hourlyEmployeeList = null;
		try {
			stmt = con.createStatement();
			rs = stmt.executeQuery(SELECT_ALL_HOURLY_EMPLOYEE);
			hourlyEmployeeList = new ArrayList<HourlyEmployee>();
			while(rs.next()) {
				HourlyEmployee hourlyEmp = new HourlyEmployee(rs.getString(2), rs.getString(3), rs.getInt(1), rs.getDouble(4), rs.getDouble(5));
				hourlyEmployeeList.add(hourlyEmp);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			closeResources(rs, stmt, con);
		}
		return hourlyEmployeeList;
	}

	@Override
	public List<CommissionEmployee> getAllCommissionEmployee() {
		Connection con = ConnectionManager.getConnection();
		Statement stmt = null;
		ResultSet rs = null;
		List<CommissionEmployee> commissionEmployeeList = null;
		try {
			stmt = con.createStatement();
			rs = stmt.executeQuery(SELECT_ALL_COMMISSION_EMPLOYEE);
			commissionEmployeeList = new ArrayList<CommissionEmployee>();
			while(rs.next()) {
				CommissionEmployee commissionEmp = new CommissionEmployee(rs.getString(2), rs.getString(3), rs.getInt(1), rs.getDouble(4), rs.getDouble(5));
				commissionEmployeeList.add(commissionEmp);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			closeResources(rs, stmt, con);
		}
		return commissionEmployeeList;
	}

	@Override
	public List<SalariedCommissionEmployee> getAllSalariedCommissionEmployee() {
		Connection con = ConnectionManager.getConnection();
		Statement stmt = null;
		ResultSet rs = null;
		List<SalariedCommissionEmployee> salariedCommissionEmployeeList = null;
		try {
			stmt = con.createStatement();
			rs = stmt.executeQuery(SELECT_ALL_SALARIED_COMMISSION_EMPLOYEE);
			salariedCommissionEmployeeList = new ArrayList<SalariedCommissionEmployee>();
			while(rs.next()) {
				SalariedCommissionEmployee salariedCommissionEmp = new SalariedCommissionEmployee(rs.getString(2), rs.getString(3), rs.getInt(1), rs.getDouble(4), rs.getDouble(5), rs.getDouble(6));
				salariedCommissionEmployeeList.add(salariedCommissionEmp);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		finally {
			closeResources(rs, stmt, con);
		}
		return salariedCommissionEmployeeList;
	}

	@Override
	public List<List> getAllEmployee() {
		List<SalariedEmployee> salariedEmployeeList = getAllSalariedEmployee();
		List<HourlyEmployee> hourlyEmployeeList = getAllHourlyEmployee();
		List<CommissionEmployee> commissionEmployeeList = getAllCommissionEmployee();
		List<SalariedCommissionEmployee> salariedCommissionEmployeeList = getAllSalariedCommissionEmployee();
		
		List<List> allEmployee = new ArrayList<List>();
		allEmployee.add(salariedEmployeeList);
		allEmployee.add(hourlyEmployeeList);
		allEmployee.add(commissionEmployeeList);
		allEmployee.add(salariedCommissionEmployeeList);
		
		return allEmployee;
	}

	@Override
	public List<SalariedEmployee> getSalariedEmpById(int empId) {
		Connection con = ConnectionManager.getConnection();
		Statement stmt = null;
		ResultSet rs = null;
		List<SalariedEmployee> salariedEmpListById = null;
		try {
			PreparedStatement ps = null;
			ps = con.prepareStatement(SELECT_SALARIED_EMPLOYEE_BY_ID);
			ps.setInt(1, empId);
			rs = ps.executeQuery();
			salariedEmpListById = new ArrayList<SalariedEmployee>();
			while(rs.next()) {
				SalariedEmployee salariedEmp = new SalariedEmployee(rs.getString(2), rs.getString(3), rs.getInt(1), rs.getDouble(4), rs.getInt(6), rs.getInt(5));
				salariedEmpListById.add(salariedEmp);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			closeResources(rs, stmt, con);
		}
		
		return salariedEmpListById;
	}

	@Override
	public List<HourlyEmployee> getHourlyEmpById(int empId) {
		Connection con = ConnectionManager.getConnection();
		Statement stmt = null;
		ResultSet rs = null;
		List<HourlyEmployee> hourlyEmpListById = null;
		try {
			PreparedStatement ps = null;
			ps = con.prepareStatement(SELECT_HOURLY_EMPLOYEE_BY_ID);
			ps.setInt(1, empId);
			rs = ps.executeQuery();
			hourlyEmpListById = new ArrayList<HourlyEmployee>();
			while(rs.next()) {
				HourlyEmployee hourlyEmp = new HourlyEmployee(rs.getString(2), rs.getString(3), rs.getInt(1), rs.getDouble(4), rs.getDouble(5));
				hourlyEmpListById.add(hourlyEmp);
			};
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			closeResources(rs, stmt, con);
		}
		
		return hourlyEmpListById;
	}

	@Override
	public List<CommissionEmployee> getCommissionEmpById(int empId) {
		Connection con = ConnectionManager.getConnection();
		Statement stmt = null;
		ResultSet rs = null;
		List<CommissionEmployee> commissionEmpListById = null;
		try {
			PreparedStatement ps = null;
			ps = con.prepareStatement(SELECT_COMMISSION_EMPLOYEE_BY_ID);
			ps.setInt(1, empId);
			rs = ps.executeQuery();
			commissionEmpListById = new ArrayList<CommissionEmployee>();
			while(rs.next()) {
				CommissionEmployee commissionEmp = new CommissionEmployee(rs.getString(2), rs.getString(3), rs.getInt(1), rs.getDouble(4), rs.getDouble(5));
				commissionEmpListById.add(commissionEmp);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			closeResources(rs, stmt, con);
		}
		
		return commissionEmpListById;
	}

	@Override
	public List<SalariedCommissionEmployee> getSalariedCommissionEmpById(int empId) {
		Connection con = ConnectionManager.getConnection();
		Statement stmt = null;
		ResultSet rs = null;
		List<SalariedCommissionEmployee> salariedCommissionEmpListById = null;
		try {
			PreparedStatement ps = null;
			ps = con.prepareStatement(SELECT_SALARIED_COMMISSION_EMPLOYEE_BY_ID);
			ps.setInt(1, empId);
			rs = ps.executeQuery();
			salariedCommissionEmpListById = new ArrayList<SalariedCommissionEmployee>();
			while(rs.next()) {
				SalariedCommissionEmployee salariedCommissionEmp = new SalariedCommissionEmployee(rs.getString(2), rs.getString(3), rs.getInt(1), rs.getDouble(4), rs.getDouble(5), rs.getDouble(6));
				salariedCommissionEmpListById.add(salariedCommissionEmp);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			closeResources(rs, stmt, con);
		}
		
		return salariedCommissionEmpListById;
	}
	
		
}
