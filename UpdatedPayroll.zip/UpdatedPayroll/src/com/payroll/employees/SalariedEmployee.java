package com.payroll.employees;

import java.util.Calendar;
import java.util.GregorianCalendar;

public class SalariedEmployee extends Employee{

	private double monthlySalary;
	private int workingDays;
	private int salaryMonth;

//	/public SalariedEmployee() {}
	public SalariedEmployee(String fullName, String email, int empId, double monthlySalary, int workingDays, int salaryMonth) {
		super(fullName, email, empId);
		setWorkingDays(workingDays);
		this.salaryMonth = salaryMonth;
	}

	public double getMonthlySalary() {
		return monthlySalary;
	}
	

	public void setMonthlySalary(double monthlySalary) {
		if(monthlySalary >= 0.0) {
			this.monthlySalary = monthlySalary;
		}
		else {
			throw new IllegalArgumentException("Monthly salary must be >= 0.0");
		}
	}
	
	
	public int getWorkingDays() {
		return workingDays;
	}


	public void setWorkingDays(int workingDays) {
		if(workingDays>=0 || workingDays <= getNumberOfDays(salaryMonth)) {
			this.workingDays = workingDays;
		}
		else {
			throw new IllegalArgumentException("Working days must be between 0 - " + getNumberOfDays(salaryMonth));
		}
	}


	@Override
	public double getEarnings() {
		//salary of one day = monthly salary / number of days in the particular month.
		//salary of one day * number of working days.
		return (getMonthlySalary()/getNumberOfDays(salaryMonth)) * getWorkingDays();
	}
	
	public static int getNumberOfDays(int monthNumber) {
		  int month;
		  if(monthNumber >= 1 && monthNumber <= 12) {
			  month = monthNumber;  
		  }
		  else {
			  throw new IllegalArgumentException("Enter valid entry between 1 - 12 only.");
		  }
		  // GregorianCalendar months range from 0 to 11
		  month = month - 1;
		 
		  //Year is hardcoded
		  int year = 2019; 
		 
		  Calendar cal = new GregorianCalendar();
		  cal.set(Calendar.YEAR, year);
		  cal.set(Calendar.MONTH, month);
		 
		  int noOfDays = cal.getActualMaximum(Calendar.DAY_OF_MONTH);
		 
		  return noOfDays; 
			  
	  }

}

//class SalariedEmployee2 extends Employee{
//
//	private HourlyEmployee he;
//
//	public SalariedEmployee2(String fullName, String email, int empId, double weeklySalary) {
//		super(fullName, email, empId);
//		he = new HourlyEmployee(fullName, email, empId, weeklySalary/40, 40);
//	}
//
//
////	public double getWeeklySalary() {
////		return weeklySalary;
////	}
////	
////
////	public void setWeeklySalary(double weeklySalary) {
////		if(weeklySalary >= 0.0) {
////			this.weeklySalary = weeklySalary;
////		}
////		else {
////			throw new IllegalArgumentException("Weekly salary must be >= 0.0");
////		}
////	}
//
//	
//	@Override
//	public double getEarnings() {
//		return he.getEarnings();
//	}
//
//}
