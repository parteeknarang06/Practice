package com.payroll.employees;

public class HourlyEmployee extends Employee{
	
	//wage per hour
	private double hourlyWage;
	//no of hours worked
	private double hoursWorked;
	
	
	
	public HourlyEmployee(String fullName, String email, int empId, double hourlyWage, double hoursWorked) {
		super(fullName, email, empId);
		setHourlyWage(hourlyWage);
		setHoursWorked(hoursWorked);
	}



	public double getHourlyWage() {
		return hourlyWage;
	}



	public void setHourlyWage(double hourlyWage) {
		if(hourlyWage >= 0.0) {
			this.hourlyWage = hourlyWage;
		}
		else {
			throw new IllegalArgumentException("Hourly wage must be >= 0.0");
		}
		
	}



	public double getHoursWorked() {
		return hoursWorked;
	}



	public void setHoursWorked(double hoursWorked) {
		if(hoursWorked >= 0.0 && hoursWorked <= 168) {
			this.hoursWorked = hoursWorked;
		}
		else {
			throw new IllegalArgumentException("Worked hours must be between 0 - 168, "
					+ "there can't be more than 168 hours in a week!");
		}
		
	}



	@Override
	//calculate earnings
	public double getEarnings() {
		if(getHoursWorked() <= 40) {
			//usual rate of working for 40 hrs or less.
			return getHoursWorked() * getHourlyWage();
		}
		else {
			//usual rate of working for 40 hrs + 1.5 times the hourly rate for working more than 40 hrs.
			return 40 * getHourlyWage() + (getHoursWorked() - 40) * getHourlyWage() * 1.5;
		}

	}
	
	
	
}
