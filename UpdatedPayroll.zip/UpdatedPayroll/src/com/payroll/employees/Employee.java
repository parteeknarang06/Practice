package com.payroll.employees;

public abstract class Employee {
	
	private String fullName;
	private String email;
	private int empId;
	private int holiday;
	
	public int getHoliday() {
		return holiday;
	}


	public void setHoliday(int holiday) {
		this.holiday = holiday;
	}


	public Employee(String fullName, String email, int empId) {
		this.fullName = fullName;
		this.email = email;
		this.empId = empId;
	}
	
	
	public String getFullName() {
		return fullName;
	}



	public void setFullName(String fullName) {
		this.fullName = fullName;
	}



	public String getEmail() {
		return email;
	}



	public void setEmail(String email) {
		this.email = email;
	}



	public int getEmpId() {
		return empId;
	}



	public void setEmpId(int empId) {
		this.empId = empId;
	}


	//@Override
	public String toString() {
		return "Name: " + fullName + " email: " + email + " employee ID: " + empId;
	}
	
	//abstract method overridden by subclasses
	//this method will be implemented to calculate earnings
	public abstract double getEarnings();
	
}
