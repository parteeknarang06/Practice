package com.payroll.employees;

public class CommissionEmployee extends Employee{
	private double rate;
	private double sale;
	
	
	
	public CommissionEmployee(String fullName, String email, int empId, double rate, double sale) {
		super(fullName, email, empId);
		setRate(rate);
		setSale(sale);
	}
	
	public double getRate() {
		return rate;
	}
	public void setRate(double rate) {
		assert rate > 0.0 && rate < 1.0 : "employee can't earn commission more than sale value";
		//employee can't earn commission more than sale value
		//if(rate > 0.0 && rate < 1.0) {
			this.rate = rate;
		//}
		
	}
	public double getSale() {
		return sale;
	}
	public void setSale(double sale) {
		if(sale >= 0.0) {
			this.sale = sale;
		}
		else {
			throw new IllegalArgumentException("sale must be >= 0");
		}
		
	}
	
	@Override
	public double getEarnings() {
		return getSale() * getRate();
	}
	
	
	
}
