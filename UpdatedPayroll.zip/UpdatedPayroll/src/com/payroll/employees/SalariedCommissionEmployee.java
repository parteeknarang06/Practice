package com.payroll.employees;

public class SalariedCommissionEmployee extends CommissionEmployee{
	
	private double salary;
	private double bonus;
	private int workingDays;
	private int salaryMonth;
	//private SalariedEmployee se = new SalariedEmployee(fullName, email, empId, monthlySalary, workingDays, salaryMonth);
	public SalariedCommissionEmployee(String fullName, String email, int empId, double rate, double sale, double salary, int salaryMonth, int workingDays) {
		super(fullName, email, empId, rate, sale);
		setSalary(salary);
	}

		
	public double getSalary() {
		return salary;
	}

	
	public void setSalary(double salary) {
		if(salary >= 0.0) {
			this.salary = salary;
		}
		else {
			throw new IllegalArgumentException("salary must be > 0");
		}
	}
	
	
	@Override
	public double getEarnings() {
		//total earnings = base salary + commission earnings
		return getSalary() + super.getEarnings();
	}
	
	
	public double getBonus() {
		return bonus;
	}
	
	
	public void setBonus(double bonusPercentage) {
		//Bonus calculation, percentage of salary
		this.bonus = (bonusPercentage/100) * getSalary();
		//bonus addition in base salary
		setSalary( getSalary() + getBonus() );
	}


	public int getWorkingDays() {
		return workingDays;
	}


	public void setWorkingDays(int workingDays) {
		if(workingDays>=0 || workingDays <= SalariedEmployee.getNumberOfDays(salaryMonth)) {
			this.workingDays = workingDays;
		}
		else {
			throw new IllegalArgumentException("Working days must be between 0 - " + SalariedEmployee.getNumberOfDays(salaryMonth));
		}
	}


	public int getSalaryMonth() {
		return salaryMonth;
	}


	public void setSalaryMonth(int salaryMonth) {
		this.salaryMonth = salaryMonth;
	}
	
	
}
